from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from datetime import datetime

app = Flask(__name__)

client = MongoClient("mongodb://localhost:27017/")
db = client["healthcare"]
appointments = db["appointments"]

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/book', methods=["POST"])
def book():
    name = request.form["name"]
    email = request.form["email"]
    doctor = request.form["doctor"]
    date = request.form["date"]
    time = request.form["time"]

    appointments.insert_one({
        "name": name,
        "email": email,
        "doctor": doctor,
        "date": date,
        "time": time,
        "timestamp": datetime.now()
    })
    return redirect(url_for('view_appointments'))

@app.route('/appointments')
def view_appointments():
    all_appointments = appointments.find().sort("timestamp", -1)
    return render_template("appointments.html", appointments=all_appointments)

if __name__ == '__main__':
    app.run(debug=True)
